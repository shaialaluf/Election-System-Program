#include "Citizen.h"
#include <string>
#include "District.h"
#pragma warning(disable: 4996) // disable strcpy error

Citizen::Citizen(char* name, int id, int birth_year,  District* d, bool isVoted) : name(nullptr),
	 isVoted(isVoted),d(nullptr) // citizen constructor
{
	if (!set_Birth_Year(birth_year))
		this->birth_year = -1;

	if (!set_id(id))
		this->id = -2;

	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
	this->d = d;
}
Citizen::~Citizen() // citizen destructor
{
	delete[] name;
}

Citizen::Citizen(const Citizen& c) // citizen copy constructor
{
	*this = c;
}

const Citizen& Citizen::operator=(const Citizen& other) // citizen operator= 
{
	if (this != &other)
	{
		delete[] name;
		id = other.id;
		birth_year = other.birth_year;
		d = other.d;
		//district_num = other.d->get_serial_number();
		isVoted = other.isVoted;
		name = new char[strlen(other.name)+1];
		strcpy(this->name, other.name);
	}

	return *this;

}

ostream& operator<<(ostream& os, const Citizen& c) // citizen operator<< 
{
	os << "name: "<<c.name << " , id: " << c.id << " , birth year: " << c.birth_year << " , district num: " << (c.d)->get_serial_number() << endl;
	return os;
}

bool Citizen::set_Birth_Year(int birth_year) // set birth year of a citizen. return false if the year is smaller than 1900 (and not set the year)
{
	if (birth_year > 0 && birth_year < 2020)
	{
		this->birth_year = birth_year;
		return true;
	}
		
	else
		return false;
		
}


bool Citizen::set_id(int id) // set id of a citizen. return false if the id is smaller than 0 (and not set the id)
{
	if (id > 0)
	{
		this->id = id;
		return true;
	}

	else
		return false;
		
}

void Citizen::set_isVoted(bool isvoted) // setter of isVoted data member
{
	this->isVoted = isvoted;
}

void Citizen::set_district(District* district)
{
	this->d = district;
}