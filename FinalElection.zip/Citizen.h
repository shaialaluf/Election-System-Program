#pragma once
#include <iostream>

class District;
using namespace std;
class Citizen
{
	private:

		char* name;
		int id;
		District* d;
		int birth_year;
		bool isVoted;
	public:
		Citizen(char* name, int id, int birth_year, District* d,bool isVoted = false);
		~Citizen();
		Citizen() { name = nullptr; d = nullptr; }
		Citizen(const Citizen& c);
		const Citizen& operator=(const Citizen& other);
		friend ostream& operator<<(ostream& os, const Citizen& c);
		char* getName() const { return name; }
		int getId()  const { return id; }
		int getBirth_Year() const { return birth_year; }
		District* getDistrict_Citizen() const { return d; }
		bool getIs_Voted() const { return isVoted; }
		bool set_Birth_Year(int birth_year);
		bool set_id(int id);
		void set_isVoted(bool isvoted);
		void set_district(District* district);
};


