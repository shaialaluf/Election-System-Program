#include "District.h"
#include "PartyArray.h"
#include <string.h>
#pragma warning(disable: 4996) // disable strcpy error

int District::serial_number_generator=0; // automatic counter 

District::District(char* name, int number_of_representatives, PartyArray* results_size) :  // District constructor
	serial_number(serial_number_generator++), number_of_representatives(number_of_representatives), 
	percent_of_all(0), results_size(nullptr) ,number_of_voters(0),
	winner_party_index(-1)
{
	this->results_size = results_size;

	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
	results = new PartyResult[this->results_size->get_phs()];

} 

District::~District() // District destructor
{
	delete[] name;
	delete[] results;
}


void District::addCitizenToDistrict(const Citizen& c) // gets a citizen and add him to the citizen array inside the district
{
	citizens_of_district.addCitizen(c);
}

ostream& operator<<(ostream& os, const District& d) // District operator<<
{
	os << d.serial_number << ". " << "name of district: "<<d.name << " , number of representatives: " << d.number_of_representatives << endl;
	return os;
}


District::District(const District& d) // District copy constructor
{
	*this = d;
}

const District& District::operator=(const District& other) // District operator=
{
	if (this != &other)
	{
		delete[] name;
		delete[] results;
		number_of_representatives = other.number_of_representatives;
		serial_number = other.serial_number;
		percent_of_all = other.percent_of_all;
		results_size = other.results_size;
		number_of_voters = other.number_of_voters;
		winner_party_index = other.winner_party_index;
		citizens_of_district = other.citizens_of_district;
	
		name = new char[strlen(other.name) + 1];
		strcpy(this->name, other.name);

		results = new PartyResult[results_size->get_phs()];//results_phs];
		for (int i = 0; i < results_size->get_logs(); i++)
		{
			results[i].votes_number = other.results[i].votes_number;
			results[i].elected_representatives = other.results[i].elected_representatives;
		}

	}

	return *this;
}

void District::set_results(int party_id) // gets party id and update the vote of the citizen in results array
{
	results[party_id].votes_number++;
	number_of_voters++;

}

void District::set_percent_of_all() // set the percent of the citizens that voted from the district
{
	percent_of_all = ((number_of_voters * 100) / citizens_of_district.get_logs()) ;
}

void District::set_winner_party_index() // set the id of the party with the most number of votes in this district
{
	int max = -1;
	int index	;
	for (int i = 0; i < results_size->get_logs(); i++)
		if (results[i].votes_number > max)
		{
			max = results[i].votes_number;
			index = i;
		}

	this->winner_party_index = index;

}

void District::resize_results() // resize the results array when place is over
{
	PartyResult* temp = new PartyResult[results_size->get_phs()];

	for (int i = 0; i < results_size->get_logs()-1; i++)
	{
		temp[i].votes_number = results[i].votes_number;
		temp[i].elected_representatives = results[i].elected_representatives;
	}

	delete[] results;
	results = temp;


}

void District::update_num_of_parties() // update the logical size of results array - when adding new party
{

	results[results_size->get_logs() - 1].votes_number = 0;
}

int District::get_parties_number() const
{ 
	return results_size->get_logs(); 
}

int District::get_results_phs() const
{
	return results_size->get_phs(); 
}

void District::update_citizens()
{
	for (int i = 0; i < this->citizens_of_district.get_logs(); i++)
	{
		this->citizens_of_district.get_citizen_by_index(i).set_district(this);
	}
}