﻿#pragma once
class PartyArray;
#include "CitizenArray.h"

class District
{
	private:
		char* name;
		int serial_number;
		static int serial_number_generator;
		CitizenArray citizens_of_district;
		int percent_of_all;
		struct PartyResult
		{
			int votes_number=0;
			CitizenArray elected_representatives;
		};
		PartyResult* results; 
		PartyArray* results_size;
		int number_of_representatives;
		int number_of_voters; 
		int winner_party_index; 

	public:
		District(char* name, int number_of_representatives,PartyArray* results_size);
		~District();
		void addCitizenToDistrict(const Citizen& c);
		District() { name = nullptr; results = nullptr; }
		friend ostream& operator<<(ostream& os, const District& d);
		District(const District& d);
		const District& operator=(const District& other);
		void set_results(int party_id);
		void set_percent_of_all();
		int get_percent_of_all() const { return percent_of_all; }
		char* get_name() const { return name; }
		int get_number_of_representatives() const { return number_of_representatives; }
		void set_winner_party_index();
		int get_winner_party_index() const { return winner_party_index; }
		int get_parties_number() const;
		int get_results_phs() const;
		void resize_results();
		void update_num_of_parties();
		PartyResult* get_results() const { return results; }
		int get_number_of_voters() const { return number_of_voters; }
		int get_serial_number() const { return serial_number; }
		void update_citizens();
		CitizenArray& get_citizens_of_district () { return citizens_of_district; }


};

