#include "DistrictArray.h"


DistrictArray::DistrictArray(int phs) :  // DistrictArray constructor
	phs(phs), arr(new District[phs]), logs(0)
{

}

DistrictArray::~DistrictArray() // DistrictArray destrructor
{
	delete[] arr;
}


ostream& operator<<(ostream& os, const DistrictArray& da) // DistrictArray operator<<
{
	for (int i = 0; i < da.logs; i++)
		os << da.arr[i];

	return os;
}

void DistrictArray::addDistrict(const District& d) // add new district the array and resize it when place is over
{
	if (logs < phs)
		arr[logs] = d;
	else
		resize(phs, d);

	logs++;
}

void DistrictArray::resize(int phs, const District& d) // resize the district array to a double size
{
	District* temp = new District[phs * 2];
	for (int i = 0; i < phs; i++)
	{
		temp[i] = arr[i];
	}

	delete[] arr;
	arr = temp;
	this->phs *= 2;
	arr[logs] = d;

	for (int i = 0; i < logs; i++)
		arr[i].update_citizens();

}

DistrictArray::DistrictArray(const DistrictArray& da) // DistrictArray copy constructor
{
	*this = da;
}

const DistrictArray& DistrictArray::operator=(const DistrictArray& other)// DistrictArray operator=
{
	if (this != &other)
	{
		delete[] arr;
		logs = other.logs;
		phs = other.phs;
		arr = new District[phs];
		for (int i = 0; i < other.logs; i++)
			arr[i] = other.arr[i];
	}

	return *this;
}

void DistrictArray::add_party_to_districts() // add a new party to all the districts 
{
	for (int i = 0; i < logs; i++)
	{
		if (arr[i].get_parties_number() + 1 >= arr[i].get_results_phs())
		{
			arr[i].resize_results();
		}

		arr[i].update_num_of_parties();
	}
}