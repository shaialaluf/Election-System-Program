#include "Elections.h"

Elections::Elections(int day, int month, int year) // Elections constructor
{
	if (!set_Year(year))
		this->year = -1;

	if (!set_Month(month))
		this->month = -1;

	if (!set_Day(day))
		this->day = -1;

	results_sum = nullptr;
}


Elections::~Elections() // Elections destructor
{
	delete[] results_sum;
}


bool Elections::set_Year(int year) // set the year that elections occur. Year must be bigger than 1000.
{
	if (year >= 1000)
	{
		this->year = year;
		return true;
	}

	else
		return false;
}

bool Elections::set_Day(int day) // set the day that elections occur. 
{
	if (day >= 1 && day <= 30)
	{
		this->day = day;
		return true;
	}

	else
		return false;
}

bool Elections::set_Month(int month) // set the month that elections occur.
{
	if (month >= 1 && month <= 12)
	{
		this->month = month;
		return true;
	}

	else
		return false;
}

bool Elections::build_representative_list() // init and update the results array when the elections is over. It creates the representatives list for each party according to the results
{
	float ratio;
	int number_of_representatives;
	int count = 0;
	if (districts.get_logs() == 0)
		return false;

	for (int i = 0; i < districts.get_logs(); i++)
	{
		for (int j = 0; j < districts.get_district_by_index(i).get_parties_number() - 1; j++)
		{
			if (districts.get_district_by_index(i).get_number_of_voters() == 0)
				ratio = 0;
			else
			{
				ratio = static_cast<float>
					(districts.get_district_by_index(i).get_results()[j].votes_number) /
					districts.get_district_by_index(i).get_number_of_voters();
			}

			number_of_representatives = ratio * districts.get_district_by_index(i).get_number_of_representatives();
			count += number_of_representatives;

			CitizenArray* ca = parties.getParty_by_index(j).get_representatives_by_district();

			if (number_of_representatives > ca[i].get_logs()) // there is an error when the party have less representatives than the district gave her
				return false;
 

			for (int k = 0; k < number_of_representatives; k++)
				if (ca->get_logs() - 1 >= k)
				{
					districts.get_district_by_index(i).get_results()[j].elected_representatives.addCitizen(ca->get_citizen_by_index(k));
				}


			
		}
		// the last party gets the remain representatives to avoid losing representatives
		int j = districts.get_district_by_index(i).get_parties_number() - 1;
		number_of_representatives = districts.get_district_by_index(i).get_number_of_representatives() - count;
		CitizenArray* ca = parties.getParty_by_index(j).get_representatives_by_district();
		if (number_of_representatives > ca[i].get_logs())
			return false;
		for (int k = 0; k < number_of_representatives; k++)
			if (ca[i].get_logs() - 1 >= k)
			{
				districts.get_district_by_index(i).get_results()[j].elected_representatives.addCitizen(ca[i].get_citizen_by_index(k));
			}
	}
	return true;
}


void Elections::init_results_sum() // creates new array for the results. Here we pad zeros to reset it for later use
{
	int size = parties.get_logs();
	if (results_sum != nullptr)
		delete results_sum;
	results_sum = new sumOfResult[size];
	for (int i = 0; i < size; i++)
	{
		results_sum[i].party_id = i;
		results_sum[i].sum_of_representatives = 0;
		results_sum[i].sum_of_votes = 0;
	}

	for (int i = 0; i < districts.get_logs(); i++)
	{
		for (int j = 0; j < size; j++)
		{
			results_sum[j].sum_of_votes += districts.get_district_by_index(i).get_results()[j].votes_number;
		}

		int winner_of_district = districts.get_district_by_index(i).get_winner_party_index();
		results_sum[winner_of_district].sum_of_representatives += districts.get_district_by_index(i).get_number_of_representatives();
	}


}
void Elections::sort_results_sum() // sort the new array of results - from the party with the most sum of representatives to the least one
{
	sumOfResult temp;
	int size = parties.get_logs();
	for (int i = 0; i < size - 1; i++)
		for (int j = 0; j < size - i - 1; j++)
		{
			if (results_sum[j].sum_of_representatives < results_sum[j + 1].sum_of_representatives)
			{
				temp.party_id = results_sum[j].party_id;
				temp.sum_of_representatives = results_sum[j].sum_of_representatives;
				temp.sum_of_votes = results_sum[j].sum_of_votes;

				results_sum[j].party_id = results_sum[j + 1].party_id;
				results_sum[j].sum_of_representatives = results_sum[j + 1].sum_of_representatives;
				results_sum[j].sum_of_votes = results_sum[j + 1].sum_of_votes;

				results_sum[j + 1].party_id = temp.party_id;
				results_sum[j + 1].sum_of_representatives = temp.sum_of_representatives;
				results_sum[j + 1].sum_of_votes = temp.sum_of_votes;

			}
		}

}

void Elections::update_citizens_pinkas() 
{
		for (int j = 0; j < districts.get_logs(); j++)
		{
			for (int k = 0; k < districts.get_district_by_index(j).get_citizens_of_district().get_logs(); k++)
			{

				Citizen c = districts.get_district_by_index(j).get_citizens_of_district().get_citizen_by_index(k);

				citizens.FindCitizenById(c.getId())->set_district(c.getDistrict_Citizen());
			}
		}
	
}


