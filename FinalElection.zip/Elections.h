#pragma once
#include "CitizenArray.h"
#include "PartyArray.h"
#include "DistrictArray.h"
class Elections
{
	private:
		int day;
		int month;
		int year;
		CitizenArray citizens;
		PartyArray parties;
		DistrictArray districts;
		struct sumOfResult{
		
			int party_id;
			int sum_of_representatives;
			int sum_of_votes;
		};

		sumOfResult* results_sum=nullptr;

	public:
		Elections(int day, int month, int year);
		~Elections();
		const DistrictArray& get_districts() const { return districts; }
		const PartyArray& get_parties() const { return parties; }
		const CitizenArray& get_citizens() const { return citizens; }
		DistrictArray& get_districts()  { return districts; }
		PartyArray& get_parties()  { return parties; }
		CitizenArray& get_citizens()  { return citizens; }
		bool set_Year(int year);
		bool set_Day(int day);
		bool set_Month(int month);

		int get_Year() const { return year; }
		int get_Day() const { return day; }
		int get_Month() const { return month; }

		bool build_representative_list();
		void init_results_sum();
		void sort_results_sum();
		sumOfResult* get_results_sum() const { return results_sum; }
		void update_citizens_pinkas();
};

