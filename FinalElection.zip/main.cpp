﻿#include "CitizenArray.h"
#include "PartyArray.h"
#include "DistrictArray.h"
#include "Elections.h"
#include <iostream>
using namespace std;

void main()
{
	int choice;

	int day, month, year;

	cout << "Please enter date of the elections by day, month, year: ";
	cin >> day >> month >> year;
	Elections elections(day, month, year);
	if (elections.get_Day() == -1)
	{
		cout << "invalid day" << endl;
		exit(0);
	}


	if (elections.get_Month() == -1)
	{
		cout << "invalid month" << endl;
		exit(0);
	}


	if (elections.get_Year() == -1)
	{
		cout << "invalid year" << endl;
		exit(0);
	}


	const int MAX = 100;
	int birth_year;
	char name[MAX];

	int number_of_representatives;
	Citizen* representative;
	Citizen* chief;
	Citizen* citizen_p;
	Citizen citizen;
	District* Citizen_Home;
	int party_id, district_id, citizen_id;


	cout << "Please choose a number between 1-10:" << endl;
	cout << "1. Add district" << endl;
	cout << "2. Add citizen" << endl;
	cout << "3. Add party" << endl;
	cout << "4. Add representive to a party" << endl;
	cout << "5. Show all the districts at the country" << endl;
	cout << "6. Show all the citizens at the country" << endl;
	cout << "7. Show all the parties at the country " << endl;
	cout << "8. Make a vote" << endl;
	cout << "9. Show the elections results" << endl;
	cout << "10. Exit program" << endl;
	cin >> choice;
	while (choice != 10)
	{
	
		switch (choice) {
			
		case 1:
			cout << "Please enter district name and number of representatives: ";
			cin >> name >> number_of_representatives;
			
			
			
			if (number_of_representatives >= 0)
			{
				District district(name, number_of_representatives, &(elections.get_parties()));
				elections.get_districts().addDistrict(district);
				elections.get_parties().add_district_to_parties();
				elections.update_citizens_pinkas();
			}
			
			break;

		case 2:
			cout << "Please enter name, id, birth year and district num: ";
			cin >> name >> citizen_id >> birth_year >> district_id;
			Citizen_Home = &(elections.get_districts().get_district_by_index(district_id));
			citizen=Citizen(name, citizen_id, birth_year, Citizen_Home, false);
			if (citizen.getBirth_Year() == -1)
				cout << "invalid birth year " << endl;
			else if (citizen.getId() == -2)
				cout << "invalid id" << endl;

			else if (elections.get_districts().get_logs() - 1 < district_id)
				cout << "invalid district num " << endl;
			else
			{
				elections.get_citizens().addCitizen(citizen); // add to pinkas
				elections.get_districts().get_district_by_index(citizen.getDistrict_Citizen()->get_serial_number()).addCitizenToDistrict(citizen);// add citizen inside district
				
				elections.get_districts().get_district_by_index(citizen.getDistrict_Citizen()->get_serial_number()).set_percent_of_all();
			}

			break;

		case 3:
			cout << "Please enter name of the party, chief party id:";
			cin >> name>>citizen_id;
			chief = elections.get_citizens().FindCitizenById(citizen_id);

			if (elections.get_parties().is_citizen_chief(citizen_id))
				cout << "This citizen is already a chief" << endl;

			else if (chief != nullptr)
			{
				elections.get_parties().addParty(name, *chief, &(elections.get_districts()));
				elections.get_districts().add_party_to_districts();
			}

			else
				cout << "This is not a citizen!" << endl;
			break;

		case 4:
			cout << "Please enter id of representative, party id, district id:";
			cin >> citizen_id >> party_id >> district_id;
	
			representative = elections.get_citizens().FindCitizenById(citizen_id);
			if (representative == nullptr)
				cout << "This is not a citizen!" << endl;
			else if (!elections.get_parties().Is_Representative(citizen_id))
				cout << "This citizen is already representative or chief" << endl;

			else if (elections.get_parties().get_logs() < party_id + 1)
				cout << "invalid party id" << endl;

			else if (elections.get_districts().get_logs() < district_id + 1)
				cout << "invalid district id" << endl;

			else
			{
				elections.get_parties().getParty_by_index(party_id).addRepresentative(*representative, district_id);
			}
			break;

		case 5:
			cout << "The districts are:" << endl;
			cout << elections.get_districts();
			break;

		case 6:
			cout << "The citizens are:" << endl;
			cout << elections.get_citizens();
			break;

		case 7:
			cout << "The parties are:" << endl;
			cout << elections.get_parties();
			break;

		case 8:
			cout << "Please enter your id and party id: ";
			cin >> citizen_id >> party_id;
			citizen_p = elections.get_citizens().FindCitizenById(citizen_id);
			if (citizen_p == nullptr)
				cout << "This is not a citizen!" << endl;

			else if (citizen_p->getIs_Voted())
				cout << "citizen already voted" << endl;

			else if (elections.get_parties().get_logs() < party_id + 1)
				cout << "invalid party id" << endl;

			else
			{
				citizen_p->set_isVoted(true);
				elections.get_districts().get_district_by_index(citizen_p->getDistrict_Citizen()->get_serial_number()).set_results(party_id);
				elections.get_districts().get_district_by_index(citizen_p->getDistrict_Citizen()->get_serial_number()).set_percent_of_all();

			}

			break;

		case 9:
			if (!elections.build_representative_list())
				cout << "cant calculate results"<<endl;
			else {

				for (int i = 0; i < elections.get_districts().get_logs(); i++)
				{
					cout << endl;
					cout << "district name: ";
					cout << elections.get_districts().get_district_by_index(i).get_name() << endl;
					cout << "number_of_representatives:";
					cout << elections.get_districts().get_district_by_index(i).get_number_of_representatives() << endl;
					elections.get_districts().get_district_by_index(i).set_winner_party_index();
					int winner_party = elections.get_districts().get_district_by_index(i).get_winner_party_index();
					cout << "name of the chief party that won in the district: ";
					cout << elections.get_parties().getParty_by_index(winner_party).get_chief_party().getName() << endl;
					cout << "the precent of all the voters in the district " << i << " is : ";
					elections.get_districts().get_district_by_index(i).set_percent_of_all();
					cout << elections.get_districts().get_district_by_index(i).get_percent_of_all() << endl;

					for (int j = 0; j < elections.get_districts().get_district_by_index(i).get_parties_number(); j++)
					{
						cout << "the elected representatives of party number " << j << " are: ";
						cout << elections.get_districts().get_district_by_index(i).get_results()[j].elected_representatives << endl;
						cout << "number of votes for party number " << j << " is: ";
						cout << elections.get_districts().get_district_by_index(i).get_results()[j].votes_number << endl;
						cout << "precent of votes for party number " << j << " is: ";

						int percent = 100 * (elections.get_districts().get_district_by_index(i).get_results()[j].votes_number) /
							elections.get_districts().get_district_by_index(i).get_number_of_voters();

						cout << percent << endl;

					}

				}

				elections.init_results_sum();
				elections.sort_results_sum();

				int party_index;


				for (int i = 0; i < elections.get_parties().get_logs(); i++)
				{

					party_index = elections.get_results_sum()[i].party_id;
					cout << endl;
					cout << "The name of the party: " << elections.get_parties().getParty_by_index(party_index).get_name() << endl;
					cout << "The name of the chief: " << elections.get_parties().getParty_by_index(party_index).get_chief_party().getName() << endl;
					cout << "sum of representatives: " << elections.get_results_sum()[i].sum_of_representatives << endl;;
					cout << "sum of votes: " << elections.get_results_sum()[i].sum_of_votes << endl;
					cout << endl;
				}
			}
			break;

		case 10:
			exit(0);
			break;

		default:
			cout << "There is no option like this " << endl;
			break;


			
			
		}
		cout << endl;
		cout << "Please choose a number between 1-10:" << endl;
		cout << "1. Add district" << endl;
		cout << "2. Add citizen" << endl;
		cout << "3. Add party" << endl;
		cout << "4. Add representive to a party" << endl;
		cout << "5. Show all the districts at the country" << endl;
		cout << "6. Show all the citizens at the country" << endl;
		cout << "7. Show all the parties at the country " << endl;
		cout << "8. Make a vote" << endl;
		cout << "9. Show the elections results" << endl;
		cout << "10. Exit program" << endl<<endl;
		cin >> choice;

	}

	cout << "goodbye" << endl;
}
